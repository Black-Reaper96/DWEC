<template>
  <v-container grid-list-xl>
    <v-layout row wrap>

      <v-flex md6>
        <v-card class="mb-3 pa-4" v-for="(item, index) in listaTareas" :key="index">
          <v-card-text>
            <v-chip
              class="mb-2"
              color="pink"
              label
              text-color="white"
            >
              <v-icon left>label</v-icon>
              {{item.titulo}}
            </v-chip>
            <p>{{item.descripcion}}</p>
          </v-card-text>
          <v-btn color="warning" class="ml-4">Editar</v-btn>
          <v-btn color="error" class="ml-3">Eliminar</v-btn>
        </v-card>

        <!--<v-card class="mb-3 pa-4">
          <v-card-text>
            <v-chip
              class="mb-2"
              color="pink"
              label
              text-color="white"
            >
              <v-icon left>label</v-icon>
              Titulo tarea #2
            </v-chip>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
              Minus vel consequuntur quidem corporis laborum ipsa officia 
              aut earum debitis quod reiciendis cupiditate aspernatur ipsam, 
              sunt sapiente quia distinctio expedita quos.</p>
          </v-card-text>
          <v-btn color="warning" class="ml-4">Editar</v-btn>
          <v-btn color="error" class="ml-3">Eliminar</v-btn>
        </v-card>-->

      </v-flex>

      <v-flex md6 >
        <v-card class="mb-3 pa-3">
          <v-form @submit.prevent="agregarTarea">
            <v-text-field label="Titulo de la tarea" v-model="titulo"></v-text-field>
            <v-textarea label="Descripcion de la tarea" v-model="descripcion"></v-textarea>
            <v-btn block class="success" type="submit"> Agregar tarea</v-btn>
          </v-form>
        </v-card>
      </v-flex>
    </v-layout>

    <v-snackbar
      v-model="snackbar"
    >
      {{ mensaje }}
      <v-btn
        color="pink"
        text
        @click="snackbar = false"
      >
        Close
      </v-btn>
    </v-snackbar>

  </v-container>
</template>

<script>

export default {
  name: 'home',

  data(){
    return{
      listaTareas:[
        {id: 1, titulo: 'titulo tarea #1', descripcion: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vel consequuntur quidem corporis laborum ipsa officia aut earum debitis quod reiciendis cupiditate aspernatur ipsam, sunt sapiente quia distinctio expedita quos.'},
        {id: 2, titulo: 'titulo tarea #2', descripcion: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vel consequuntur quidem corporis laborum ipsa officia aut earum debitis quod reiciendis cupiditate aspernatur ipsam, sunt sapiente quia distinctio expedita quos.'},
        {id: 3, titulo: 'titulo tarea #3', descripcion: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vel consequuntur quidem corporis laborum ipsa officia aut earum debitis quod reiciendis cupiditate aspernatur ipsam, sunt sapiente quia distinctio expedita quos.'},
      ],
      titulo: '',
      descripcion: '',
      snackbar: false,
      mensaje: ''

    }
  },

  methods:{
    agregarTarea(){
      console.log(this.titulo, this.descripcion);
      if(this.titulo == '' || this.descripcion == ''){
        this.snackbar = true
        this.mensaje = 'Llena todos los campos!!!'
      }else{
        this.listaTareas.push({
          id: Date.now(),
          titulo: this.titulo,
          descripcion: this.descripcion
        })
        this.titulo = '',
        this.descripcion = ''
        this.snackbar = true
        this.mensaje='Tarea agregada con exito'
      }
    }
  }
}
</script>
